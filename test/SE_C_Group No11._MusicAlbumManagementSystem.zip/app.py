# app.py
from flask import Flask, render_template, request, redirect ,session, jsonify ,url_for
from flask_sqlalchemy import SQLAlchemy
from flask import redirect, url_for
import matplotlib.pyplot as plt
import io
import base64
from base64 import *



app = Flask(__name__)
app.secret_key = 'f5c2a34b9f9a4f6d87265e4ba6d48b4c'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///D:/Dnyaneshwari/Python/sqlite3/Database/users.db'
db = SQLAlchemy(app)
artists = {
    '1': {
        'name': 'Artist 1',
        'albums': [
            {'name': 'Album 1', 'cover': 'Album 1'},
            {'name': 'Album 2', 'cover': 'Album 2'},
            # Add more albums for Artist 1
        ],
        'songs': [
            {'name': 'Harshal', 'album': 'Chaleya.jpg', 'genre': 'Genre 1', 'duration': '3:30'},
            {'name': 'Aakash', 'album': 'TumseHe.jpg', 'genre': 'Genre 2', 'duration': '4:00'},
            # Add more songs for Artist 1
        ]
    },
    '2': {
        'songs': [
            {'name': 'Song 3', 'album': 'Album 3', 'genre': 'Genre 3', 'duration': '2:45'},
            {'name': 'Song 4', 'album': 'Album 4', 'genre': 'Genre 4', 'duration': '3:15'},
            # Add more songs for Artist 2
        ]
    }
    # Add more artists as needed
}
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
     
class MoodEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(1000), db.ForeignKey('user.id'), nullable=False)
    mood_type = db.Column(db.String(50), nullable=False)
    mood_count = db.Column(db.Integer, nullable=False)
    
    def __repr__(self):
        return f"MoodEntry(user_id={self.user_name}, mood_type='{self.mood_type}')"
    
with app.app_context():
    db.create_all()
    
@app.route('/update_mood', methods=['POST'])
def update_mood():
    if request.method == 'POST':
        user_name = request.form['user_name']  # Assuming the username is sent in the form data
        mood_type = request.form['mood_type']  # Assuming the mood type is sent in the form data
        
        # Check if the user has already entered the same mood type today
        existing_entry = MoodEntry.query.filter_by(user_name=user_name, mood_type=mood_type).first()
        if existing_entry:
            # If the entry already exists, increment the mood_count
            existing_entry.mood_count += 1
        else:
            # If it doesn't exist, create a new entry
            new_entry = MoodEntry(user_name=user_name, mood_type=mood_type, mood_count=1)
            db.session.add(new_entry)
        
        # Commit the changes to the database
        db.session.commit()
        
        return redirect(url_for('index'))  # Redirect the user to the homepage or any other page after updating the mood


    
    
@app.route('/')
def registration():
    return render_template('registration.html')

@app.route('/register', methods=['POST'])
def register():
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    email = request.form['email']
    password = request.form['password']
    
    # Check if the email is already registered
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        return "Email already exists. Please use a different email."

    # Create a new user
    new_user = User(first_name=first_name, last_name=last_name, email=email, password=password)
    db.session.add(new_user)
    db.session.commit()
    session['email'] = email
    session['first_name'] = first_name
    session['last_name'] = last_name
    # return 'Registration successful!' 
    return redirect('/login')

@app.route('/index')
def index():
    if 'email' in session:
        return render_template('index.html', email=session['email'])
    else:
        return redirect(url_for('login'))  # Redirect to the login route

@app.route('/artist/<artist_id>')
def get_artist_songs(artist_id):
    return jsonify(artists.get(artist_id, {'songs': []}))

@app.route('/login',methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Query the database for the user
        user = User.query.filter_by(email=email).first()

        if user and user.password == password:
            # User authenticated successfully
            session['email'] = email 
            # Store username in session
            session['first_name'] = user.first_name  # Store first name in session
            session['last_name'] = user.last_name
            return redirect(url_for('index', email=email))  # Pass email as parameter to index route

        else:
            # Authentication failed
            return render_template('login.html', error='Invalid email or password')

    return render_template('login.html')

@app.route('/playlist')
def playlist():
    user_info = {
        'first_name': session.get('first_name'),
        'last_name': session.get('last_name'),
        'email': session.get('email')
    }
    return render_template('playlist_page.html',user_info=user_info)  


@app.route('/mymedia')
def mymedia():
    return render_template('mymedia.html')

@app.route('/index2')
def index2():
    return render_template('index2.html')

@app.route('/account')
def account():
    # Get user information from session
    user_email = session.get('email')
    user_info = {
        'first_name': session.get('first_name'),
        'last_name': session.get('last_name'),
        'email': user_email
    }
    
    # Query the database to retrieve mood entries for the current user
    mood_entries = MoodEntry.query.filter_by(user_name=user_email).all()
    
    # Process the data to create a bar chart
    mood_types = [entry.mood_type for entry in mood_entries]
    mood_counts = [entry.mood_count for entry in mood_entries]
    
    plt.bar(mood_types, mood_counts)
    plt.xlabel('Mood Type')
    plt.ylabel('Mood Count')
    plt.title('Mood Entry Bar Chart')
    
    # Save the chart as an image
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    chart_url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    
    # Render the HTML page with the chart and user information
    return render_template('account.html', user_info=user_info, chart_url=chart_url)
    




@app.route('/play_song/<int:song_id>')
def play_song(song_id):
    # Fetch the song details based on the song_id
    # Replace the below code with your logic to fetch song details
    song_details = {
        'album_cover_url': 'url_to_album_cover',
        'audio_url': 'url_to_audio_file',
        'song_name': 'Song Name'
    }
    return jsonify(song_details)

if __name__ == '__main__':
    app.run(debug=True)
